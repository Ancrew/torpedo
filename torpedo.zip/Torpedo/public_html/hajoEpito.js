var egyseg


init();
function init(){
    epito(2);
    epito(3);
    epito(4);
}

function epito(){
    
}
